import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { SuppliersComponent } from './suppliers/suppliers.component';
import { AdminRoutingModule } from './admin-routing.module';
import { SupplierHomeComponent } from './supplier-home/supplier-home.component';
import { SupplierAddressComponent } from './supplierAddress/supplierAddress.component';

@NgModule({
  declarations: [
    AdminHomeComponent,
    SuppliersComponent,
    SupplierAddressComponent,
    SupplierHomeComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AdminRoutingModule
  ],
  exports: [
    AdminRoutingModule,
    AdminHomeComponent,
    SuppliersComponent,
    SupplierAddressComponent,
    SupplierHomeComponent
  ]
})
export class AdminModule { }

